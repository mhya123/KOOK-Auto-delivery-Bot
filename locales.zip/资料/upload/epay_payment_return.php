<?php
/**
 * Epay 支付成功返回页面
 * 用户支付完成后浏览器跳转到这里
 */

$dir = __DIR__;
require($dir . '/src/XF.php');

XF::start($dir);
$app = XF::setupApp('XF\Pub\App');

// 获取参数并确保变量都有默认值
$trade_status = $_GET['trade_status'] ?? '';
$out_trade_no = $_GET['out_trade_no'] ?? '';

// 设置页面标题和消息
$pageTitle = '支付结果';
$message = '支付处理中，请稍候...';
$messageClass = 'blockMessage--none';
$redirectUrl = $app->router('public')->buildLink('canonical:account/upgrades');

if ($trade_status === 'TRADE_SUCCESS') {
    $message = '支付成功！系统正在处理您的订单，请稍候...';
    $messageClass = 'blockMessage--success';
}

// 输出HTML
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <style>
        :root {
            --primary-color: #3498db;
            --success-color: #2ecc71;
            --info-color: #3498db;
            --warning-color: #f39c12;
            --danger-color: #e74c3c;
            --light-color: #f8f9fa;
            --dark-color: #343a40;
            --text-color: #333;
            --border-radius: 12px;
            --shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif;
            line-height: 1.6;
            color: var(--text-color);
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .container {
            width: 100%;
            max-width: 500px;
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            overflow: hidden;
            transition: var(--transition);
        }
        
        .header {
            background: var(--primary-color);
            color: white;
            padding: 20px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .header p {
            opacity: 0.9;
            font-size: 0.9rem;
        }
        
        .content {
            padding: 30px;
        }
        
        .status-card {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .status-icon {
            width: 80px;
            height: 80px;
            margin: 0 auto 20px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 40px;
        }
        
        .status-icon.success {
            background: rgba(46, 204, 113, 0.1);
            color: var(--success-color);
        }
        
        .status-icon.processing {
            background: rgba(52, 152, 219, 0.1);
            color: var(--info-color);
        }
        
        .status-title {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .status-message {
            color: #666;
            margin-bottom: 20px;
            line-height: 1.5;
        }
        
        .order-info {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin: 20px 0;
            text-align: left;
        }
        
        .order-info h3 {
            font-size: 1rem;
            margin-bottom: 10px;
            color: #555;
        }
        
        .order-info p {
            font-family: monospace;
            background: white;
            padding: 8px 12px;
            border-radius: 6px;
            font-size: 0.9rem;
            word-break: break-all;
        }
        
        .countdown-section {
            margin: 25px 0;
            padding: 15px;
            background: rgba(52, 152, 219, 0.05);
            border-radius: 8px;
        }
        
        .countdown-text {
            font-size: 1rem;
            margin-bottom: 10px;
        }
        
        #countdown {
            font-weight: 700;
            color: var(--primary-color);
            font-size: 1.2rem;
        }
        
        .progress-bar {
            height: 6px;
            background: #e9ecef;
            border-radius: 3px;
            overflow: hidden;
            margin-top: 10px;
        }
        
        .progress-fill {
            height: 100%;
            width: 0;
            background: var(--primary-color);
            border-radius: 3px;
            transition: width 1s linear;
        }
        
        .actions {
            display: flex;
            gap: 15px;
            margin-top: 25px;
        }
        
        .btn {
            flex: 1;
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            text-align: center;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-primary {
            background: var(--primary-color);
            color: white;
        }
        
        .btn-primary:hover {
            background: #2980b9;
            transform: translateY(-2px);
        }
        
        .btn-outline {
            background: transparent;
            color: var(--primary-color);
            border: 1px solid var(--primary-color);
        }
        
        .btn-outline:hover {
            background: rgba(52, 152, 219, 0.1);
        }
        
        .loading-animation {
            display: inline-block;
            width: 40px;
            height: 40px;
            border: 4px solid rgba(52, 152, 219, 0.3);
            border-radius: 50%;
            border-top-color: var(--info-color);
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .pulse {
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
        
        @media (max-width: 480px) {
            .content {
                padding: 20px;
            }
            
            .actions {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>支付结果</h1>
            <p>感谢您的付款，系统正在处理您的订单</p>
        </div>
        
        <div class="content">
            <div class="status-card">
                <div class="status-icon <?php echo $trade_status === 'TRADE_SUCCESS' ? 'success pulse' : 'processing'; ?>">
                    <?php if ($trade_status === 'TRADE_SUCCESS'): ?>
                        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                            <polyline points="22 4 12 14.01 9 11.01"></polyline>
                        </svg>
                    <?php else: ?>
                        <div class="loading-animation"></div>
                    <?php endif; ?>
                </div>
                
                <h2 class="status-title">
                    <?php echo $trade_status === 'TRADE_SUCCESS' ? '支付成功！' : '支付处理中'; ?>
                </h2>
                
                <p class="status-message">
                    <?php echo htmlspecialchars($message); ?>
                </p>
            </div>
            
            <?php if (!empty($out_trade_no)): ?>
            <div class="order-info">
                <h3>订单信息</h3>
                <p>订单号: <?php echo htmlspecialchars($out_trade_no); ?></p>
            </div>
            <?php endif; ?>
            
            <div class="countdown-section">
                <p class="countdown-text">
                    页面将在 <span id="countdown">3</span> 秒后自动跳转
                </p>
                <div class="progress-bar">
                    <div class="progress-fill" id="progressFill"></div>
                </div>
            </div>
            
            <div class="actions">
                <a href="<?php echo htmlspecialchars($redirectUrl); ?>" class="btn btn-primary">立即返回</a>
                <a href="#" class="btn btn-outline" onclick="location.reload()">刷新状态</a>
            </div>
        </div>
    </div>

    <script>
        // 倒计时功能
        let count = 3;
        const countdownEl = document.getElementById('countdown');
        const progressFill = document.getElementById('progressFill');
        
        // 初始化控制台信息
        console.group('Epay 支付返回页面');
        console.log('时间:', new Date().toLocaleString('zh-CN'));
        console.log('当前URL:', window.location.href);
        
        // 解析URL参数
        const urlParams = new URLSearchParams(window.location.search);
        const params = {};
        for (let pair of urlParams.entries()) {
            params[pair[0]] = pair[1];
        }
        
        console.group('回调参数');
        console.table(params);
        console.groupEnd();
        
        console.log('订单号:', params.out_trade_no || '未提供');
        console.log('交易号:', params.trade_no || '未提供');
        console.log('交易状态:', params.trade_status || '未提供');
        console.log('金额:', params.money || '未提供');
        console.log('支付方式:', params.type || '未提供');
        
        // 启动倒计时
        console.log('启动倒计时: ' + count + '秒后跳转');
        console.log('跳转目标:', <?php echo json_encode($redirectUrl); ?>);
        
        const timer = setInterval(function() {
            count--;
            if (count > 0) {
                countdownEl.textContent = count;
                progressFill.style.width = ((3 - count) / 3 * 100) + '%';
                console.log('倒计时: ' + count + '秒');
            } else {
                clearInterval(timer);
                progressFill.style.width = '100%';
                console.log('倒计时结束，开始跳转...');
                console.groupEnd();s
                window.location.href = <?php echo json_encode($redirectUrl); ?>;
            }
        }, 1000);
        
        // 页面加载完成
        window.addEventListener('load', function() {
            console.log('页面加载完成');
            // 初始化进度条
            progressFill.style.width = '0%';
        });
        
        // 监听页面卸载（跳转前）
        window.addEventListener('beforeunload', function() {
            console.log('页面即将跳转...');
        });
    </script>
</body>
</html>