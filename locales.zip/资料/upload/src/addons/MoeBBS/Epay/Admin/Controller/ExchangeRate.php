<?php
namespace MoeBBS\Epay\Admin\Controller;

use XF\Admin\Controller\AbstractController;
use XF\Mvc\ParameterBag;

class ExchangeRate extends AbstractController
{
    /**
     * 显示汇率管理页面
     */
    public function actionIndex()
    {
        $apiUrl = 'https://yunapi.cn/api/huilv';
        $cacheFile = \XF::getRootDirectory() . '/mpay_rates_cache.json';
        
        // 读取缓存
        $cachedRates = null;
        $cacheTime = null;
        if (file_exists($cacheFile)) {
            $cacheData = @json_decode(file_get_contents($cacheFile), true);
            if ($cacheData && isset($cacheData['rates']) && isset($cacheData['timestamp'])) {
                $cachedRates = $cacheData['rates'];
                $cacheTime = $cacheData['timestamp'];
            }
        }
        
        // 读取手动配置
        $manualRates = \XF::options()->mpay_exchange_rates;
        if (is_string($manualRates)) {
            $manualRates = @json_decode($manualRates, true) ?: [];
        }
        if (!is_array($manualRates)) {
            $manualRates = [];
        }
        
        $viewParams = [
            'apiUrl' => $apiUrl,
            'cachedRates' => $cachedRates,
            'cacheTime' => $cacheTime,
            'manualRates' => $manualRates,
            'cacheAge' => $cacheTime ? (time() - $cacheTime) : null
        ];
        
        return $this->view('MoeBBS\Epay:ExchangeRate\Index', 'moebbs_epay_exchange_rate', $viewParams);
    }
    
    /**
     * 刷新汇率缓存
     */
    public function actionRefresh()
    {
        $this->assertPostOnly();
        
        $apiUrl = 'https://yunapi.cn/api/huilv';
        $cacheFile = \XF::getRootDirectory() . '/mpay_rates_cache.json';
        
        try {
            $context = stream_context_create([
                'http' => [
                    'timeout' => 10,
                    'ignore_errors' => true
                ]
            ]);
            
            $response = @file_get_contents($apiUrl, false, $context);
            if ($response === false) {
                return $this->error('无法连接到汇率API,请检查网络连接。');
            }
            
            $rates = @json_decode($response, true);
            if (!is_array($rates) || empty($rates)) {
                return $this->error('API返回的数据格式不正确。');
            }
            
            // 保存到缓存
            $cacheData = [
                'timestamp' => time(),
                'rates' => $rates
            ];
            file_put_contents($cacheFile, json_encode($cacheData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            
            return $this->redirect($this->buildLink('moebbs-epay/exchange-rate'), '汇率已成功更新!');
        } catch (\Exception $e) {
            return $this->error('刷新汇率时发生错误: ' . $e->getMessage());
        }
    }
    
    /**
     * 清除缓存
     */
    public function actionClearCache()
    {
        $this->assertPostOnly();
        
        $cacheFile = \XF::getRootDirectory() . '/mpay_rates_cache.json';
        if (file_exists($cacheFile)) {
            @unlink($cacheFile);
        }
        
        return $this->redirect($this->buildLink('moebbs-epay/exchange-rate'), '缓存已清除!');
    }
    
    /**
     * 测试API连接
     */
    public function actionTest()
    {
        $apiUrl = 'https://yunapi.cn/api/huilv';
        
        try {
            $startTime = microtime(true);
            
            $context = stream_context_create([
                'http' => [
                    'timeout' => 10,
                    'ignore_errors' => true
                ]
            ]);
            
            $response = @file_get_contents($apiUrl, false, $context);
            $duration = round((microtime(true) - $startTime) * 1000, 2);
            
            if ($response === false) {
                return $this->error("API连接失败!\n\n无法连接到 {$apiUrl}\n请检查:\n1. 服务器网络连接\n2. 防火墙设置\n3. API地址是否正确");
            }
            
            $rates = @json_decode($response, true);
            if (!is_array($rates) || empty($rates)) {
                return $this->error("API返回数据格式错误!\n\n响应内容:\n" . substr($response, 0, 500));
            }
            
            $message = "✓ API连接成功!\n\n";
            $message .= "响应时间: {$duration}ms\n";
            $message .= "获取到 " . count($rates) . " 种货币汇率\n\n";
            $message .= "部分汇率示例:\n";
            $count = 0;
            foreach ($rates as $currency => $rate) {
                $message .= "  {$currency}: {$rate}\n";
                if (++$count >= 10) {
                    $message .= "  ... 共 " . count($rates) . " 种货币\n";
                    break;
                }
            }
            
            return $this->message($message);
        } catch (\Exception $e) {
            return $this->error('测试失败: ' . $e->getMessage());
        }
    }
}
