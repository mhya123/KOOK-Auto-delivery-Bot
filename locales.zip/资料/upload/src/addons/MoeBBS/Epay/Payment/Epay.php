<?php
namespace MoeBBS\Epay\Payment;

use AlipaySubmit;
use XF\Entity\PurchaseRequest;
use XF\Mvc\Controller;
use XF\Payment\AbstractProvider;
use XF\Payment\CallbackState;
use XF\Purchasable\Purchase;

require_once("Lib/epay_submit.class.php");

class Epay extends AbstractProvider
{
    // 支持所有货币,自动转换为CNY
    protected $supportedCurrencies = [];

    public function getTitle()
    {
        return 'Epay';
    }

    /**
     * 从API获取实时汇率
     * @return array|null 汇率数组或null(失败时)
     */
    protected function fetchExchangeRates()
    {
        $apiUrl = 'https://yunapi.cn/api/huilv';
        $cacheKey = 'mpay_exchange_rates_cache';
        $cacheFile = __DIR__ . '/../../../../../mpay_rates_cache.json';
        $cacheDuration = 3600; // 缓存1小时

        // 检查缓存
        if (file_exists($cacheFile)) {
            $cacheData = @json_decode(file_get_contents($cacheFile), true);
            if ($cacheData && isset($cacheData['timestamp']) && isset($cacheData['rates'])) {
                if (time() - $cacheData['timestamp'] < $cacheDuration) {
                    return $cacheData['rates'];
                }
            }
        }

        // 从API获取
        try {
            $context = stream_context_create([
                'http' => [
                    'timeout' => 5,
                    'ignore_errors' => true
                ]
            ]);

            $response = @file_get_contents($apiUrl, false, $context);
            if ($response === false) {
                return null;
            }

            $rates = @json_decode($response, true);
            if (!is_array($rates) || empty($rates)) {
                return null;
            }

            // 保存到缓存
            $cacheData = [
                'timestamp' => time(),
                'rates' => $rates
            ];
            @file_put_contents($cacheFile, json_encode($cacheData, JSON_PRETTY_PRINT));

            return $rates;
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * 将其他货币转换为人民币(CNY)
     * @param float $amount 金额
     * @param string $currency 货币代码
     * @return float 转换后的人民币金额
     */
    protected function convertToCNY($amount, $currency)
    {
        // 如果已经是CNY,直接返回
        if (strtoupper($currency) === 'CNY') {
            return $amount;
        }

        $currency = strtoupper($currency);
        $exchangeRates = [];

        // 优先级1: 尝试从API获取实时汇率
        $apiRates = $this->fetchExchangeRates();
        if ($apiRates && isset($apiRates[$currency])) {
            $exchangeRates = $apiRates;
        } else {
            // 优先级2: 从后台选项获取手动配置的汇率
            $manualRates = \XF::options()->mpay_exchange_rates;

            // 如果配置是JSON字符串,解码它
            if (is_string($manualRates)) {
                $manualRates = @json_decode($manualRates, true) ?: [];
            }

            if (is_array($manualRates)) {
                $exchangeRates = $manualRates;
            }
        }

        // 如果汇率表中有该货币,进行转换
        if (isset($exchangeRates[$currency]) && $exchangeRates[$currency] > 0) {
            $convertedAmount = $amount * floatval($exchangeRates[$currency]);

            // 记录转换日志
            $debugLog = function ($msg) {
                $logFile = __DIR__ . '/../../../../../mpay_currency_convert.log';
                $timestamp = date('Y-m-d H:i:s');
                file_put_contents($logFile, "[{$timestamp}] {$msg}\n", FILE_APPEND);
            };
            $source = $apiRates ? 'API' : 'Manual';
            $debugLog("货币转换[{$source}]: {$amount} {$currency} × {$exchangeRates[$currency]} = {$convertedAmount} CNY");

            return $convertedAmount;
        }

        // 如果汇率表中没有该货币,记录警告并使用1:1汇率(不转换)
        $debugLog = function ($msg) {
            $logFile = __DIR__ . '/../../../../../mpay_currency_warning.log';
            $timestamp = date('Y-m-d H:i:s');
            file_put_contents($logFile, "[{$timestamp}] {$msg}\n", FILE_APPEND);
        };

        $debugLog("警告: 未找到货币 {$currency} 的汇率(API和手动配置均未找到),使用原始金额 {$amount}。请在后台【设置 → MoeBBS Epay → 货币汇率】中配置汇率。");

        return $amount;
    }

    /**
     * @return string
     */
    public function getCallbackUrl()
    {
        return \XF::app()->options()->boardUrl . '/epay_payment_callback.php?_xfProvider=' . $this->providerId;
    }

    /**
     * @return string
     */
    public function getReturnUrl()
    {
        return \XF::app()->options()->boardUrl . '/epay_payment_return.php?_xfProvider=' . $this->providerId;
    }

    /**
     * @param PurchaseRequest $purchaseRequest
     * @param Purchase $purchase
     * @param string $paymentType
     * @return array
     */
    protected function getPaymentParams(PurchaseRequest $purchaseRequest, Purchase $purchase, $paymentType = 'wxpay')
    {
        $paymentProfile = $purchase->paymentProfile;
        $options = $paymentProfile->options;

        // 获取原始金额和货币
        $originalAmount = $purchase->cost;
        $originalCurrency = $purchase->currency;

        // 转换为CNY
        $amountInCNY = $this->convertToCNY($originalAmount, $originalCurrency);

        // 记录转换日志
        if (strtoupper($originalCurrency) !== 'CNY') {
            $debugLog = function ($msg) {
                $logFile = __DIR__ . '/../../../../../mpay_currency_convert.log';
                $timestamp = date('Y-m-d H:i:s');
                file_put_contents($logFile, "[{$timestamp}] {$msg}\n", FILE_APPEND);
            };
            $debugLog("货币转换: {$originalAmount} {$originalCurrency} => {$amountInCNY} CNY");
        }

        return [
            'pid' => $options['partner'],
            'type' => $paymentType,
            'notify_url' => $this->getCallbackUrl(),  // 异步回调（后台处理升级）
            'return_url' => $this->getReturnUrl(),     // 同步跳转（用户看到的页面）
            'out_trade_no' => $purchaseRequest->request_key,
            'name' => $purchase->title,
            'money' => number_format($amountInCNY, 2, '.', ''),  // 使用转换后的CNY金额
            'sitename' => \XF::options()->boardTitle ?: 'XenForo'
        ];
    }

    public function initiatePayment(Controller $controller, PurchaseRequest $purchaseRequest, Purchase $purchase)
    {
        // ==================== 许可证验证 ====================
        $options = \XF::options();
        $isActivated = $options->mpay_license_status ?? false;

        if (!$isActivated) {
            throw new \XF\PrintableException(
                '支付功能未激活,请联系管理员配置许可证。' . PHP_EOL .
                '管理员请前往: 设置 → 许可证管理'
            );
        }
        // ==================== 许可证验证结束 ====================

        $paymentProfile = $purchase->paymentProfile;
        $options = $paymentProfile->options;

        // 调试日志：记录配置信息
        $debugLog = function ($msg) {
            $logFile = __DIR__ . '/../../../../../mpay_initiate_debug.log';
            $timestamp = date('Y-m-d H:i:s');
            file_put_contents($logFile, "[{$timestamp}] {$msg}\n", FILE_APPEND);
        };

        $debugLog("=== 支付初始化 ===");
        $debugLog("商户PID配置: " . (isset($options['partner']) ? $options['partner'] : '未设置'));
        $debugLog("商户KEY配置: " . (isset($options['key']) ? '已设置' : '未设置'));
        $debugLog("API地址配置: " . (isset($options['apiurl']) ? $options['apiurl'] : '未设置'));

        // 为每种支付方式生成签名
        $paymentTypes = ['wxpay', 'alipay', 'qqpay'];
        $paymentForms = [];

        foreach ($paymentTypes as $paymentType) {
            // 构建支付参数
            $params = $this->getPaymentParams($purchaseRequest, $purchase, $paymentType);

            // 调试：记录生成的参数
            $debugLog("支付方式: {$paymentType}");
            $debugLog("PID参数: " . (isset($params['pid']) ? $params['pid'] : '未生成'));
            $debugLog("金额参数: " . (isset($params['money']) ? $params['money'] : '未生成'));

            // 生成签名：按照易支付API文档的签名算法
            // 1. 过滤空值和签名参数
            $signParams = array_filter($params, function ($value) {
                return $value !== '' && $value !== null;
            });

            // 2. 按key排序
            ksort($signParams);

            // 3. 拼接成 key=value&key=value 格式
            $signStr = '';
            foreach ($signParams as $key => $value) {
                $signStr .= $key . '=' . $value . '&';
            }

            // 4. 去掉最后的&，然后追加密钥key
            $signStr = rtrim($signStr, '&');
            $signStr .= $options['key'];

            // 5. MD5加密
            $sign = md5($signStr);

            $params['sign'] = $sign;
            $params['sign_type'] = isset($options['sign_type']) ? $options['sign_type'] : 'MD5';

            $paymentForms[$paymentType] = $params;
        }

        // 获取支付API地址（从支付配置中获取）
        $apiUrl = isset($options['apiurl']) && !empty($options['apiurl'])
            ? rtrim($options['apiurl'], '/')
            : 'https://pay.example.com';

        // 计算转换后的金额用于前端显示
        $originalAmount = $purchase->cost;
        $originalCurrency = $purchase->currency;
        $convertedAmount = $this->convertToCNY($originalAmount, $originalCurrency);
        $needConversion = strtoupper($originalCurrency) !== 'CNY';

        $viewParams = [
            'paymentForms' => $paymentForms,
            'purchase' => $purchase,
            'paymentProfile' => $paymentProfile,
            'apiUrl' => $apiUrl,
            'originalAmount' => $originalAmount,
            'originalCurrency' => $originalCurrency,
            'convertedAmount' => $convertedAmount,
            'needConversion' => $needConversion
        ];

        return $controller->view('XF:Purchase\Mpay', 'mpay_payment_initiate', $viewParams);
    }    /**
         * @param \XF\Http\Request $request
         *
         * @return CallbackState
         */
    public function setupCallback(\XF\Http\Request $request)
    {
        $state = new CallbackState();
        $state->data = $_GET;
        $state->requestKey = isset($_GET['out_trade_no']) ? $_GET['out_trade_no'] : '';
        $state->transactionId = isset($_GET['trade_no']) ? $_GET['trade_no'] : '';
        $state->sign = isset($_GET['sign']) ? $_GET['sign'] : '';
        $state->type = isset($_GET['type']) ? $_GET['type'] : '';
        $state->trade_status = isset($_GET['trade_status']) ? $_GET['trade_status'] : '';
        $state->pid = isset($_GET['pid']) ? $_GET['pid'] : '';
        $state->_GET = $_GET;

        return $state;
    }

    /**
     * 验证回调签名
     * @param CallbackState $state
     * @return bool
     */
    public function validateCallback(CallbackState $state)
    {
        $debugLog = function ($msg) {
            $logFile = __DIR__ . '/../../../../../epay_callback_debug.log';
            $timestamp = date('Y-m-d H:i:s');
            file_put_contents($logFile, "[$timestamp] [validateCallback] $msg\n", FILE_APPEND);
        };

        $debugLog("开始验证回调签名");

        $purchaseRequest = $state->getPurchaseRequest();
        if (!$purchaseRequest) {
            $state->logType = 'error';
            $state->logMessage = 'Invalid purchase request';
            $debugLog("❌ 错误: 无效的购买请求");
            return false;
        }
        $debugLog("✓ 找到购买请求: " . $purchaseRequest->request_key);

        $paymentProfile = $state->getPaymentProfile();
        if (!$paymentProfile) {
            $state->logType = 'error';
            $state->logMessage = 'Invalid payment profile';
            $debugLog("❌ 错误: 无效的支付配置");
            return false;
        }
        $debugLog("✓ 找到支付配置: " . $paymentProfile->payment_profile_id);

        $options = $paymentProfile->options;
        $debugLog("商户配置 - PID: " . ($options['partner'] ?? 'N/A') . ", KEY: " . (isset($options['key']) ? substr($options['key'], 0, 8) . '...' : 'N/A'));

        // 验证商户ID
        if (!isset($state->pid) || empty($state->pid)) {
            $state->logType = 'error';
            $state->logMessage = 'Missing pid in callback';
            $debugLog("❌ 错误: 回调中缺少 pid 参数");
            return false;
        }
        $debugLog("回调 PID: " . $state->pid);

        if ($state->pid != $options['partner']) {
            $state->logType = 'error';
            $state->logMessage = 'Invalid merchant ID: ' . $state->pid . ' vs ' . $options['partner'];
            $debugLog("❌ 错误: 商户ID不匹配 - 回调: {$state->pid}, 配置: {$options['partner']}");
            return false;
        }
        $debugLog("✓ 商户ID验证通过");

        // 构建签名字符串
        $params = $state->data;
        $sign = isset($params['sign']) ? $params['sign'] : '';
        $debugLog("收到的签名: " . $sign);

        // 移除不参与签名的参数
        unset($params['sign']);
        unset($params['sign_type']);
        unset($params['_xfProvider']); // XenForo 添加的参数，不参与签名

        // 过滤空值
        $params = array_filter($params, function ($value) {
            return $value !== '' && $value !== null;
        });
        $debugLog("过滤后的参数: " . json_encode($params, JSON_UNESCAPED_UNICODE));

        // 按key排序
        ksort($params);
        $debugLog("排序后的参数: " . json_encode($params, JSON_UNESCAPED_UNICODE));

        // 拼接签名字符串
        $signStr = '';
        foreach ($params as $key => $value) {
            $signStr .= $key . '=' . $value . '&';
        }
        $signStr = substr($signStr, 0, -1);
        $debugLog("签名字符串(不含KEY): " . $signStr);

        $signStr .= $options['key'];
        $debugLog("签名字符串(含KEY): " . substr($signStr, 0, -strlen($options['key'])) . '[KEY已隐藏]');

        // 计算签名
        $calculatedSign = md5($signStr);
        $debugLog("计算的签名: " . $calculatedSign);

        // 验证签名
        if ($calculatedSign !== $sign) {
            $state->logType = 'error';
            $state->logMessage = 'Invalid signature. Calculated: ' . $calculatedSign . ', Received: ' . $sign;
            $debugLog("❌ 签名验证失败!");
            $debugLog("  期望: " . $calculatedSign);
            $debugLog("  实际: " . $sign);
            return false;
        }

        $debugLog("✓ 签名验证通过!");
        return true;
    }

    /**
     * 验证交易是否有效
     * @param CallbackState $state
     * @return bool
     */
    public function validateTransaction(CallbackState $state)
    {
        $debugLog = function ($msg) {
            $logFile = __DIR__ . '/../../../../../epay_callback_debug.log';
            $timestamp = date('Y-m-d H:i:s');
            file_put_contents($logFile, "[$timestamp] [validateTransaction] $msg\n", FILE_APPEND);
        };

        $debugLog("开始验证交易状态");

        // 检查交易状态
        if (!isset($state->data['trade_status'])) {
            $state->logType = 'info';
            $state->logMessage = 'No trade_status in callback';
            $debugLog("❌ 错误: 回调中缺少 trade_status 参数");
            return false;
        }

        $tradeStatus = $state->data['trade_status'];
        $debugLog("交易状态: " . $tradeStatus);

        if ($tradeStatus !== 'TRADE_SUCCESS') {
            $state->logType = 'info';
            $state->logMessage = 'Trade status is not TRADE_SUCCESS: ' . $tradeStatus;
            $debugLog("❌ 交易状态不是 TRADE_SUCCESS: " . $tradeStatus);
            return false;
        }

        $debugLog("✓ 交易状态验证通过: TRADE_SUCCESS");
        return true;
    }

    public function getPaymentResult(CallbackState $state)
    {
        if (isset($state->data['trade_status']) && $state->data['trade_status'] === 'TRADE_SUCCESS') {
            $state->paymentResult = CallbackState::PAYMENT_RECEIVED;
        } else {
            $state->paymentResult = CallbackState::PAYMENT_PENDING;
        }
    }

    public function validateCost(CallbackState $state)
    {
        $debugLog = function ($msg) {
            $logFile = __DIR__ . '/../../../../../epay_callback_debug.log';
            $timestamp = date('Y-m-d H:i:s');
            file_put_contents($logFile, "[$timestamp] [validateCost] $msg\n", FILE_APPEND);
        };

        $debugLog("开始验证金额");

        $purchaseRequest = $state->getPurchaseRequest();
        $callbackMoney = isset($state->data['money']) ? floatval($state->data['money']) : 0;

        // 获取原始订单金额和货币
        $originalAmount = floatval($purchaseRequest->cost_amount);
        $originalCurrency = $purchaseRequest->cost_currency;

        // 将原始金额转换为CNY(因为易支付只接受CNY)
        $expectedMoney = $this->convertToCNY($originalAmount, $originalCurrency);

        $debugLog("回调金额(CNY): " . $callbackMoney);
        $debugLog("原始金额: {$originalAmount} {$originalCurrency}");
        $debugLog("转换后期望金额(CNY): " . $expectedMoney);

        // 比较时允许0.01的误差（避免浮点数精度问题）
        $costValidated = abs($callbackMoney - $expectedMoney) < 0.01;

        if (!$costValidated) {
            $state->logType = 'error';
            $state->logMessage = "Invalid cost amount. Expected: {$expectedMoney} CNY (from {$originalAmount} {$originalCurrency}), Received: {$callbackMoney} CNY";
            $debugLog("❌ 金额验证失败! 差额: " . abs($callbackMoney - $expectedMoney));
            return false;
        }

        $debugLog("✓ 金额验证通过");
        return true;
    }

    public function prepareLogData(CallbackState $state)
    {
        $state->logDetails = $state->_GET;
    }
}