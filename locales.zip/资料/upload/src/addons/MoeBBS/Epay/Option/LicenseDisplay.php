<?php

namespace MoeBBS\Epay\Option;

use MoeBBS\Epay\License\HWID;
use MoeBBS\Epay\License\Validator;
use XF\Option\AbstractOption;

class LicenseDisplay extends AbstractOption
{
    /**
     * 渲染HWID选项
     */
    public static function renderHwid(\XF\Entity\Option $option, array $htmlParams)
    {
        $hwid = HWID::get();
        
        return self::getTemplate('admin:mpay_option_hwid_content', $option, $htmlParams, [
            'hwid' => $hwid
        ]);
    }
    
    /**
     * 渲染许可证状态选项
     */
    public static function renderStatus(\XF\Entity\Option $option, array $htmlParams)
    {
        $status = Validator::getActivationStatus();
        
        return self::getTemplate('admin:mpay_option_license_status_content', $option, $htmlParams, [
            'status' => $status
        ]);
    }
}
