<?php
namespace MoeBBS\Epay\Option;

use XF\Option\AbstractOption;

class ExchangeRate extends AbstractOption
{
    public static function renderOption(\XF\Entity\Option $option, array $htmlParams)
    {
        $value = $option->option_value;
        
        // 如果值是JSON字符串,解码它
        if (is_string($value)) {
            $value = @json_decode($value, true) ?: [];
        }
        
        if (!is_array($value)) {
            $value = [];
        }
        
        // 常用货币列表
        $currencies = [
            'USD' => '美元',
            'EUR' => '欧元',
            'GBP' => '英镑',
            'JPY' => '日元',
            'HKD' => '港币',
            'TWD' => '新台币',
            'KRW' => '韩元',
            'SGD' => '新加坡元',
            'MYR' => '马来西亚令吉',
            'THB' => '泰铢',
            'AUD' => '澳元',
            'CAD' => '加元',
            'NZD' => '新西兰元',
            'RUB' => '卢布',
            'INR' => '印度卢比',
            'BRL' => '巴西雷亚尔',
            'ZAR' => '南非兰特',
            'MXN' => '墨西哥比索',
        ];
        
        $html = '<div class="inputGroup">';
        $html .= '<div class="block-body block-row">';
        $html .= '<div style="margin-bottom: 10px; color: #666;">';
        $html .= '设置各种货币相对于人民币(CNY)的汇率。例如: 如果1美元=7.25人民币,则USD填写7.25';
        $html .= '</div>';
        $html .= '<table class="dataList" style="width: 100%;">';
        $html .= '<thead><tr>';
        $html .= '<th style="width: 120px;">货币代码</th>';
        $html .= '<th style="width: 150px;">货币名称</th>';
        $html .= '<th>汇率(相对CNY)</th>';
        $html .= '</tr></thead>';
        $html .= '<tbody>';
        
        foreach ($currencies as $code => $name) {
            $rate = isset($value[$code]) ? $value[$code] : '';
            $inputName = $option->getFormName($htmlParams) . '[' . $code . ']';
            
            $html .= '<tr>';
            $html .= '<td><strong>' . htmlspecialchars($code) . '</strong></td>';
            $html .= '<td>' . htmlspecialchars($name) . '</td>';
            $html .= '<td><input type="text" name="' . htmlspecialchars($inputName) . '" value="' . htmlspecialchars($rate) . '" class="input" style="width: 150px;" placeholder="例: 7.25" /></td>';
            $html .= '</tr>';
        }
        
        $html .= '</tbody>';
        $html .= '</table>';
        $html .= '<div style="margin-top: 10px; padding: 10px; background: var(--xf-contentAltBg, #f7f7f7); border-left: 3px solid var(--xf-linkColor, #2196F3);">';
        $html .= '<strong>💡 提示:</strong><br>';
        $html .= '• 留空表示不支持该货币的自动转换<br>';
        $html .= '• 汇率会定期波动,建议定期更新<br>';
        $html .= '• 1 外币 = X 人民币,填写X的值';
        $html .= '</div>';
        $html .= '</div>';
        $html .= '</div>';
        
        return $html;
    }
    
    public static function verifyOption(array &$values, \XF\Entity\Option $option)
    {
        // 过滤空值并转换为浮点数
        $filtered = [];
        foreach ($values as $code => $rate) {
            if ($rate !== '' && $rate !== null) {
                $filtered[$code] = floatval($rate);
            }
        }
        
        $values = $filtered;
        return true;
    }
    
    /**
     * 获取子选项列表
     */
    public static function getSubOptions(\XF\Entity\Option $option)
    {
        // 返回空数组,因为我们使用自定义HTML渲染,不需要子选项
        return [];
    }
}
