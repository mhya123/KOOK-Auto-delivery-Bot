<?php

namespace MoeBBS\Epay\Option;

use XF\Option\AbstractOption;
use MoeBBS\Epay\License\HWID;
use MoeBBS\Epay\License\Validator;

/**
 * 许可证选项渲染类
 * 
 * 用于在后台选项页面渲染自定义许可证相关选项
 * 
 * @package MoeBBS\Epay\Option
 * @author MhYa123
 */
class License extends AbstractOption
{
    /**
     * 渲染 HWID 选项
     * 
     * @param \XF\Entity\Option $option 选项实体
     * @param array $htmlParams HTML 参数
     * @return string 渲染后的 HTML
     */
    public static function renderHwidOption(\XF\Entity\Option $option, array $htmlParams)
    {
        // 获取当前 HWID
        $hwid = HWID::get();
        
        // 渲染模板
        return \XF::app()->templater()->renderTemplate('admin:mpay_option_hwid_content', [
            'option' => $option,
            'htmlParams' => $htmlParams,
            'hwid' => $hwid
        ]);
    }

    /**
     * 渲染许可证状态选项
     * 
     * @param \XF\Entity\Option $option 选项实体
     * @param array $htmlParams HTML 参数
     * @return string 渲染后的 HTML
     */
    public static function renderStatusOption(\XF\Entity\Option $option, array $htmlParams)
    {
        // 获取激活状态
        $status = Validator::getActivationStatus();
        
        // 渲染模板
        return \XF::app()->templater()->renderTemplate('admin:mpay_option_license_status_content', [
            'option' => $option,
            'htmlParams' => $htmlParams,
            'status' => $status
        ]);
    }
}
