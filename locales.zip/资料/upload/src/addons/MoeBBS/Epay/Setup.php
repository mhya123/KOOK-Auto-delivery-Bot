<?php

namespace MoeBBS\Epay;

use XF\AddOn\AbstractSetup;
use XF\AddOn\StepRunnerInstallTrait;
use XF\AddOn\StepRunnerUpgradeTrait;
use XF\AddOn\StepRunnerUninstallTrait;

class Setup extends AbstractSetup
{
    use StepRunnerInstallTrait;
    use StepRunnerUpgradeTrait;
    use StepRunnerUninstallTrait;

    public function checkRequirements(&$errors = [], &$warnings = [])
    {
        $em = $this->app()->em();
        $existAddon = null;
        $installProviders = $this->getProviders();
        $findProviders = $em->findByIds('XF:PaymentProvider', $installProviders);
        $existProviders = $findProviders->pluckNamed('addon_id', 'provider_id');

        foreach ($existProviders as $providerId => $addonId) {
            if ($addonId != $this->addOn->getAddOnId()) {
                $errors[] = 'A function conflict was detected. Please remove the Add-on first: ' . $addonId;
            }
        }
    }

    public function installStep1()
    {
        foreach ($this->getProviders() as $id => $class) {
            $this->db()->insert(
                'xf_payment_provider',
                [
                    'provider_id' => $id,
                    'provider_class' => 'MoeBBS\\Epay:' . $class,
                    'addon_id' => $this->addOn->getAddOnId()
                ],
                'provider_id'
            );
        }
    }

    public function upgradeStep1()
    {
        $this->uninstall();
        $this->install();
    }


    public function uninstallStep1()
    {
        $this->db()->delete('xf_payment_provider', 'addon_id LIKE ?', $this->addOn->getAddOnId());
    }

    protected function getProviders()
    {
        $providers = [
            'mpay' => 'Epay'
        ];

        return $providers;
    }
}