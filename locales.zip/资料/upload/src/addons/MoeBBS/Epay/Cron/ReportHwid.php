<?php

namespace MoeBBS\Epay\Cron;

/**
 * HWID 定时上报任务
 */
class ReportHwid
{
    const API_URL = 'https://license.hvhbbs.cc/api/v2.php';

    /**
     * 执行 HWID 上报
     * 由 XenForo Cron 系统调用
     */
    public static function run()
    {
        try {
            $hwid = \MoeBBS\Epay\License\HWID::get();
            $domain = \XF::options()->boardUrl ?? '';

            self::reportToServer($hwid, $domain);
        } catch (\Exception $e) {
            // 静默失败，记录到日志
            \XF::logError('HWID Report Error: ' . $e->getMessage());
        }
    }

    /**
     * 上报 HWID 到验证站
     */
    protected static function reportToServer($hwid, $domain)
    {
        $url = self::API_URL . '?action=report_hwid';
        $data = json_encode([
            'hwid' => $hwid,
            'domain' => $domain
        ]);

        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

            $response = curl_exec($ch);
            $error = curl_error($ch);
            curl_close($ch);

            if ($error) {
                throw new \Exception('cURL Error: ' . $error);
            }

            return $response;
        }

        // 备用方法
        if (ini_get('allow_url_fopen')) {
            $opts = [
                'http' => [
                    'method' => 'POST',
                    'timeout' => 10,
                    'header' => 'Content-Type: application/json',
                    'content' => $data
                ],
                'ssl' => [
                    'verify_peer' => false,
                    'verify_peer_name' => false
                ]
            ];

            $context = stream_context_create($opts);
            return @file_get_contents($url, false, $context);
        }

        return false;
    }
}
