<?php

namespace MoeBBS\Epay\License;

/**
 * 硬件标识码 (HWID) 生成类
 * 
 * 用于生成服务器唯一标识码,用于许可证验证
 * 
 * @package MoeBBS\Epay\License
 * @author MhYa123
 * @version 1.0
 */
class HWID
{
    /**
     * 获取原始硬件标识信息
     * 
     * @return string 原始硬件标识字符串
     */
    public static function getRaw(): string
    {
        $os = strtolower(PHP_OS_FAMILY);
        $hwid = '';

        if ($os === 'windows') {
            // Windows: 获取主板序列号
            @exec('wmic baseboard get serialnumber', $output);
            if (!empty($output[1])) {
                $hwid = trim($output[1]);
            }
        } else {
            // Linux: 优先 machine-id
            if (file_exists('/etc/machine-id')) {
                $hwid = trim(file_get_contents('/etc/machine-id'));
            } elseif (file_exists('/var/lib/dbus/machine-id')) {
                $hwid = trim(file_get_contents('/var/lib/dbus/machine-id'));
            } else {
                // 再尝试 product_uuid
                @exec('cat /sys/class/dmi/id/product_uuid 2>/dev/null', $output);
                if (!empty($output[0])) {
                    $hwid = trim($output[0]);
                }
            }
        }

        // 如果前面都失败，就兜底
        if (empty($hwid)) {
            $hwid = php_uname() . gethostname();
        }

        return $hwid;
    }

    /**
     * 生成 SHA256 哈希的 HWID
     * 
     * @return string SHA256 哈希值
     */
    public static function generate(): string
    {
        $raw = self::getRaw();
        return hash('sha256', $raw);
    }

    /**
     * 获取或生成 HWID (带缓存)
     * 
     * 首次调用时生成并保存到 xf_option,后续从数据库读取
     * 
     * @return string HWID
     */
    public static function get(): string
    {
        $options = \XF::options();
        $savedHwid = $options->mpay_license_hwid ?? '';

        // 如果已有保存的 HWID,直接返回
        if (!empty($savedHwid)) {
            return $savedHwid;
        }

        // 否则生成新的 HWID 并保存
        $newHwid = self::generate();
        self::save($newHwid);

        return $newHwid;
    }

    /**
     * 保存 HWID 到数据库
     * 
     * @param string $hwid HWID 值
     * @return bool 是否保存成功
     */
    protected static function save(string $hwid): bool
    {
        try {
            $repo = \XF::repository('XF:Option');
            $repo->updateOption('mpay_license_hwid', $hwid);
            return true;
        } catch (\Exception $e) {
            \XF::logException($e, false, 'MoeBBS Epay HWID 保存失败: ');
            return false;
        }
    }

    /**
     * 获取 HWID 信息用于调试
     * 
     * @return array 包含原始和哈希后的 HWID
     */
    public static function getDebugInfo(): array
    {
        return [
            'raw' => self::getRaw(),
            'hash' => self::generate(),
            'os' => PHP_OS_FAMILY,
            'php_version' => PHP_VERSION
        ];
    }
}
