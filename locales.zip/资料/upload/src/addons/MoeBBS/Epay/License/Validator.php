<?php

namespace MoeBBS\Epay\License;

/**
 * 许可证验证器 v2
 * 支持 HWID 绑定 + 有效期验证
 */
class Validator
{
    const API_BASE_URL = 'https://license.hvhbbs.cc/license.php';
    const API_KEY = 'MhYa520';
    const CHECK_INTERVAL = 300; // 5分钟

    /**
     * 激活许可证 - 发送 HWID + 激活码到服务器
     */
    public static function activate($licenseCode)
    {
        $hwid = HWID::get();
        $url = self::API_BASE_URL;

        // 获取当前域名
        $domain = \XF::options()->boardUrl ?? '';
        if (empty($domain)) {
            $domain = $_SERVER['HTTP_HOST'] ?? '';
        }

        $postData = [
            'action' => 'activate',
            'license_code' => trim($licenseCode),
            'hwid' => $hwid,
            'domain' => $domain
        ];

        try {
            $response = self::makePostRequest($url, $postData);
            if ($response === false) {
                return ['success' => false, 'error' => '无法连接到许可证服务器'];
            }

            $data = @json_decode($response, true);

            // 调试输出
            \XF::logError('[MoeBBS Epay Debug] Activate Response: ' . $response);

            if (!$data) {
                return ['success' => false, 'error' => '服务器返回数据格式错误: ' . substr($response, 0, 200)];
            }

            if (isset($data['success']) && $data['success'] === true) {
                // 激活成功，保存信息
                \XF::repository('XF:Option')->updateOptions([
                    'mpay_license_code' => $licenseCode,
                    'mpay_license_status' => true,
                    'mpay_license_last_check' => time(),
                    'mpay_license_expires_at' => $data['expires_at'] ?? null,
                    'mpay_license_is_permanent' => $data['is_permanent'] ?? false
                ]);

                $message = '许可证激活成功';
                if ($data['is_permanent']) {
                    $message .= ' (永久授权)';
                } elseif ($data['days_remaining'] !== null) {
                    $message .= ' (剩余 ' . $data['days_remaining'] . ' 天)';
                }

                return [
                    'success' => true,
                    'message' => $message,
                    'expires_at' => $data['expires_at'] ?? null,
                    'days_remaining' => $data['days_remaining'] ?? null,
                    'is_permanent' => $data['is_permanent'] ?? false
                ];
            } else {
                return ['success' => false, 'error' => $data['error'] ?? '激活失败'];
            }
        } catch (\Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    /**
     * 验证许可证状态
     */
    public static function verify()
    {
        $options = \XF::options();
        $licenseCode = $options->mpay_license_code ?? '';

        if (empty($licenseCode)) {
            return ['valid' => false, 'error' => '没有找到许可证密钥'];
        }

        $hwid = HWID::get();
        $url = self::API_BASE_URL;

        $params = [
            'action' => 'verify',
            'license_code' => $licenseCode,
            'hwid' => $hwid
        ];

        try {
            $response = self::makeRequest($url, $params);
            if ($response === false) {
                // 网络错误时，如果之前验证通过且未过期，允许继续使用
                $lastCheck = $options->mpay_license_last_check ?? 0;
                if ((time() - $lastCheck) < 86400 * 7) { // 7天宽限期
                    return ['valid' => true, 'offline' => true, 'message' => '离线模式'];
                }
                return ['valid' => false, 'error' => '无法连接到许可证服务器'];
            }

            $data = @json_decode($response, true);
            if (!$data) {
                return ['valid' => false, 'error' => '服务器返回数据格式错误'];
            }

            if (isset($data['valid']) && $data['valid'] === true) {
                // 验证成功，更新状态
                \XF::repository('XF:Option')->updateOptions([
                    'mpay_license_status' => true,
                    'mpay_license_last_check' => time(),
                    'mpay_license_expires_at' => $data['expires_at'] ?? null,
                    'mpay_license_is_permanent' => $data['is_permanent'] ?? false
                ]);

                return [
                    'valid' => true,
                    'status' => $data['status'] ?? 'active',
                    'expires_at' => $data['expires_at'] ?? null,
                    'days_remaining' => $data['days_remaining'] ?? null,
                    'is_permanent' => $data['is_permanent'] ?? false
                ];
            } else {
                // 验证失败，禁用许可证
                \XF::repository('XF:Option')->updateOptions([
                    'mpay_license_status' => false
                ]);

                return [
                    'valid' => false,
                    'error' => $data['error'] ?? '许可证无效',
                    'status' => $data['status'] ?? 'invalid'
                ];
            }
        } catch (\Exception $e) {
            return ['valid' => false, 'error' => $e->getMessage()];
        }
    }

    /**
     * 取消激活许可证
     */
    public static function deactivate()
    {
        \XF::repository('XF:Option')->updateOptions([
            'mpay_license_code' => '',
            'mpay_license_status' => false,
            'mpay_license_last_check' => 0,
            'mpay_license_expires_at' => null,
            'mpay_license_is_permanent' => false
        ]);
        return ['success' => true, 'message' => '许可证已取消激活'];
    }

    /**
     * 重新验证许可证
     */
    public static function revalidate()
    {
        $result = self::verify();

        if ($result['valid']) {
            return [
                'success' => true,
                'message' => '许可证验证成功',
                'expires_at' => $result['expires_at'] ?? null,
                'days_remaining' => $result['days_remaining'] ?? null,
                'is_permanent' => $result['is_permanent'] ?? false
            ];
        } else {
            // 验证失败时，确保禁用许可证状态
            \XF::repository('XF:Option')->updateOptions([
                'mpay_license_status' => false
            ]);
            return ['success' => false, 'error' => $result['error'] ?? '验证失败'];
        }
    }

    /**
     * 检查并在需要时重新验证
     */
    public static function checkAndRevalidate()
    {
        $options = \XF::options();
        $isActivated = $options->mpay_license_status ?? false;
        $lastCheck = $options->mpay_license_last_check ?? 0;

        if (!$isActivated) {
            return false;
        }

        $needRevalidate = (time() - $lastCheck) > self::CHECK_INTERVAL;

        if ($needRevalidate) {
            $result = self::verify();
            return $result['valid'] ?? false;
        }

        return true;
    }

    /**
     * 检查是否已激活
     */
    public static function isActivated()
    {
        $options = \XF::options();
        return (bool) ($options->mpay_license_status ?? false);
    }

    /**
     * 带验证的激活状态检查
     */
    public static function isActivatedWithCheck()
    {
        return self::checkAndRevalidate();
    }

    /**
     * 获取激活状态详情
     */
    public static function getActivationStatus()
    {
        $options = \XF::options();
        $isActivated = $options->mpay_license_status ?? false;
        $lastCheck = $options->mpay_license_last_check ?? 0;
        $expiresAt = $options->mpay_license_expires_at ?? null;
        $isPermanent = $options->mpay_license_is_permanent ?? false;

        // 计算剩余天数
        $daysRemaining = null;
        if ($expiresAt && !$isPermanent) {
            $expiresTime = strtotime($expiresAt);
            if ($expiresTime !== false) {
                $daysRemaining = max(0, (int) ceil(($expiresTime - time()) / 86400));
            }
        }

        return [
            'activated' => $isActivated,
            'last_check' => $lastCheck,
            'last_check_formatted' => $lastCheck > 0 ? date('Y-m-d H:i:s', $lastCheck) : '从未验证',
            'next_check' => $lastCheck + self::CHECK_INTERVAL,
            'need_revalidate' => (time() - $lastCheck) > self::CHECK_INTERVAL,
            'expires_at' => $expiresAt,
            'days_remaining' => $daysRemaining,
            'is_permanent' => $isPermanent
        ];
    }

    /**
     * GET 请求
     */
    private static function makeRequest($url, $params = [])
    {
        $url = $url . '?' . http_build_query($params);

        if (function_exists('curl_init')) {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['X-API-Key: ' . self::API_KEY]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $error = curl_error($ch);
            curl_close($ch);

            if ($error) {
                throw new \Exception('cURL Error: ' . $error);
            }

            return $response;
        }

        if (ini_get('allow_url_fopen')) {
            $opts = [
                'http' => [
                    'timeout' => 10,
                    'ignore_errors' => true,
                    'header' => 'X-API-Key: ' . self::API_KEY
                ],
                'ssl' => [
                    'verify_peer' => false,
                    'verify_peer_name' => false
                ]
            ];

            $context = stream_context_create($opts);
            return @file_get_contents($url, false, $context);
        }

        throw new \Exception('无法发送 HTTP 请求');
    }

    /**
     * POST 请求
     */
    private static function makePostRequest($url, $data = [])
    {
        $jsonData = json_encode($data);

        if (function_exists('curl_init')) {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'X-API-Key: ' . self::API_KEY,
                'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept: application/json'
            ]);

            $response = curl_exec($ch);
            $error = curl_error($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $effectiveUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
            curl_close($ch);

            // 调试：记录请求详情
            \XF::logError('[MoeBBS Epay Debug] POST Request: ' . $url . ' | HTTP ' . $httpCode . ' | Effective URL: ' . $effectiveUrl);

            if ($error) {
                throw new \Exception('cURL Error: ' . $error);
            }

            return $response;
        }

        if (ini_get('allow_url_fopen')) {
            $opts = [
                'http' => [
                    'method' => 'POST',
                    'timeout' => 10,
                    'ignore_errors' => true,
                    'header' => "Content-Type: application/json\r\nX-API-Key: " . self::API_KEY,
                    'content' => $jsonData
                ],
                'ssl' => [
                    'verify_peer' => false,
                    'verify_peer_name' => false
                ]
            ];

            $context = stream_context_create($opts);
            return @file_get_contents($url, false, $context);
        }

        throw new \Exception('无法发送 HTTP 请求');
    }
}