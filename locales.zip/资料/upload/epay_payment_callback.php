<?php

// 开启详细日志记录
$logFile = __DIR__ . '/epay_callback_debug.log';
$debugLog = function($message) use ($logFile) {
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($logFile, "[$timestamp] $message\n", FILE_APPEND);
};

$debugLog("========== 新的回调请求 ==========");
$debugLog("请求时间: " . date('Y-m-d H:i:s'));
$debugLog("请求IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'Unknown'));
$debugLog("User-Agent: " . ($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'));
$debugLog("GET参数: " . json_encode($_GET, JSON_UNESCAPED_UNICODE));
$debugLog("POST参数: " . json_encode($_POST, JSON_UNESCAPED_UNICODE));

$dir = __DIR__;
require($dir . '/src/XF.php');

XF::start($dir);
$app = XF::setupApp('XF\Pub\App');

$response = $app->response();
$response->contentType('text/plain');
$request = $app->request();

$providerId = $request->filter('_xfProvider', 'str');
$debugLog("Provider ID: " . $providerId);

/** @var \XF\Entity\PaymentProvider $provider */
$provider = $app->em()->find('XF:PaymentProvider', $providerId);

if (!$provider) {
    $debugLog("错误: 未找到支付提供商");
    $response->httpCode(404)
        ->body('Unknown payment provider.')
        ->send($request);
    return;
}

$debugLog("找到支付提供商: " . $provider->provider_id);

$handler = $provider->handler;
$state = $handler->setupCallback($request);

$debugLog("setupCallback 完成，订单号: " . ($state->requestKey ?? 'N/A'));

$success = false;
$failReason = '';

if (!$handler->validateCallback($state)) {
    $failReason = 'validateCallback失败: ' . ($state->logMessage ?? '未知原因');
    $debugLog($failReason);
    $response->httpCode($state->httpCode ?: 403);
    $response->body('fail');
} else if (!$handler->validateTransaction($state)) {
    $failReason = 'validateTransaction失败: ' . ($state->logMessage ?? '未知原因');
    $debugLog($failReason);
    $response->httpCode($state->httpCode ?: 200);
    $response->body('fail');
} else if (!$handler->validatePurchaseRequest($state)) {
    $failReason = 'validatePurchaseRequest失败';
    $debugLog($failReason);
    $response->httpCode($state->httpCode ?: 404);
    $response->body('fail');
} else if (!$handler->validatePurchasableHandler($state)) {
    $failReason = 'validatePurchasableHandler失败';
    $debugLog($failReason);
    $response->httpCode($state->httpCode ?: 404);
    $response->body('fail');
} else if (!$handler->validatePaymentProfile($state)) {
    $failReason = 'validatePaymentProfile失败';
    $debugLog($failReason);
    $response->httpCode($state->httpCode ?: 404);
    $response->body('fail');
} else if (!$handler->validatePurchaser($state)) {
    $failReason = 'validatePurchaser失败';
    $debugLog($failReason);
    $response->httpCode($state->httpCode ?: 404);
    $response->body('fail');
} else if (!$handler->validatePurchasableData($state)) {
    $failReason = 'validatePurchasableData失败';
    $debugLog($failReason);
    $response->httpCode($state->httpCode ?: 403);
    $response->body('fail');
} else if (!$handler->validateCost($state)) {
    $failReason = 'validateCost失败: ' . ($state->logMessage ?? '未知原因');
    $debugLog($failReason);
    $response->httpCode($state->httpCode ?: 403);
    $response->body('fail');
} else {
    $debugLog("所有验证通过，开始处理支付");
    $handler->setProviderMetadata($state);
    $handler->getPaymentResult($state);
    $debugLog("支付结果: " . ($state->paymentResult ?? 'N/A'));
    $handler->completeTransaction($state);
    $debugLog("交易完成！");
    $success = true;
}

//记录日志
if ($state->logType) {
    $debugLog("记录XenForo日志，类型: " . $state->logType);
    try {
        $handler->log($state);
    } catch (\Exception $e) {
        $debugLog("记录日志异常: " . $e->getMessage());
        \XF::logException($e, false, "Error logging payment to payment provider: ");
    }
}

// 根据处理结果返回响应
if ($success) {
    $debugLog("✓ 回调处理成功，返回 success");
    $response->httpCode(200);
    $response->body('success');
} else {
    $debugLog("✗ 回调处理失败: " . $failReason);
    if (!$response->getBody()) {
        $response->body('fail');
    }
}

$debugLog("发送响应: " . $response->getBody());
$debugLog("========== 回调请求结束 ==========\n");

$response->send($request);